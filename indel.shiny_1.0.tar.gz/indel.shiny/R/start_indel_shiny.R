start_indel_shiny <-
function(){
	shiny::runApp(system.file('.', package='indel.shiny'))
}